//
//  Destination.swift
//  TravelPlaner
//
//  Created by TangZekun on 12/25/15.
//  Copyright © 2015 TangZekun. All rights reserved.
//

import UIKit

class Destination: NSObject
{
    var name : String?
    var image : UIImage?
    

}
